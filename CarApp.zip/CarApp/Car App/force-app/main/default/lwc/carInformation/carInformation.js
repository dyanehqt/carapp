import { LightningElement } from 'lwc';
import CarImages from '@salesforce/resourceUrl/imgresource';

export default class CarInformation extends LightningElement {
photo = CarImages + '/Car_Images/Nissan_Altima.jpg';

count = 0;
aaa;
error;
ClickNext(a)
{

    if(!this.aaa)
    {
        this.count = 0;
    }
    else
    if(a.target.label === "Next Info"){
        this.count++;
    }
    else
    if(a.target.label === "Previos Info"){
        this.count--;
        if(this.count < 0){
            this.count = 0;
        }
    }

}
}