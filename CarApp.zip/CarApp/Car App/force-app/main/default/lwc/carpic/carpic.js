import { LightningElement } from 'lwc';
import carsy from '@salesforce/resourceUrl/carsy2';

export default class Carpic extends LightningElement {
    photo = carsy + '/carsy.png';
}