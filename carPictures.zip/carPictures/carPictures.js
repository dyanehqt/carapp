import { LightningElement} from 'lwc';
import CarImages from '@salesforce/resourceUrl/imgresource';
import Description from '@salesforce/schema/Account.Description';

export default class CarPictures extends LightningElement {
    photo = [
        {
            id:"1",
            header:"Vintage Car",
            src: CarImages + '/Car_Images/Beerle_Restomods.jpg',
            description:"Color: Yellow"
        },
        {
            id:"2",
            header:"Cadillac Escalades",
            src: CarImages + '/Car_Images/Cadillac_Escalade.jpg',
            description:"Color: Maroon"
        },
        {
            id:"3",
            header:"Chevorlete Corvette",
            src: CarImages + '/Car_Images/Chevorlet_Corvette.jpg',
            description:"Color: White"
        },
        {
            id:"4",
            header:"Dodge Charger",
            src: CarImages + '/Car_Images/Dodge_Charger.jpg',
            description:"Color: White"
        },
        {
            id:"5",
            header:"Ford Mustang",
            src: CarImages + '/Car_Images/Ford_Mustang.jpg',
            description:"Color: Red"
        },
        {
            id:"6",
            header:"Ford F-150",
            src: CarImages + '/Car_Images/Ford_F_150.jpg',
            description:"Color: Blue"
        },
        {
            id:"7",
            header:"Honda Civic",
            src: CarImages + '/Car_Images/Honda_Civic.jpg',
            description:"Color: Blue"
        },
        {
            id:"8",
            header:"Jeep Cherokee",
            src: CarImages + '/Car_Images/Jeep_Cherokee.jpg',
            description:"Color: Gray"
        },
        {
            id:"9",
            header:"Jeep Wrangler",
            src: CarImages + '/Car_Images/Jeep_Wrangler.jpg',
            description:"Color: Red"
        },
        {
            id:"10",
            header:"Nissan Altima",
            src: CarImages + '/Car_Images/Nissan_Altima.jpg',
            description:"Color: Light Gray"
        },
        {
            id:"11",
            header:"Subaru Outback",
            src: CarImages + '/Car_Images/Subaru_Outback.jpg',
            description:"Color: Dark Gray"
        },
        {
            id:"12",
            header:"Toyota Highlander",
            src: CarImages + '/Car_Images/Toyota_Highlander.jpg',
            description:"Color: White"
        },
        ]
    }