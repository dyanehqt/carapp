import { LightningElement} from 'lwc';
import CarImages from '@salesforce/resourceUrl/imgresource';
import Description from '@salesforce/schema/Account.Description';

export default class Carousel extends LightningElement {

    photo = [
        {
            id:"1",
            header:"Vintage Car",
            src: CarImages + '/Car_Images/Beerle_Restomods.jpg',
            description:"Color: Yellow"
        },
        {
            id:"2",
            header:"Cadillac Escalades",
            src: CarImages + '/Car_Images/Cadillac_Escalade.jpg',
            description:"Color: Maroon" 
        },
        {
            id:"3",
            header:"Chevorlete Corvette",
            src: CarImages + '/Car_Images/Chevorlet_Corvette.jpg',
            description:"Color: White"
        },
    ]
}