import { LightningElement,wire } from 'lwc';
import getCarModel from '@salesforce/apex/DataController.fetchCarModel';
const col =[
    {
        label: 'Car Model Name',
        fieldName: 'Name',
        type:'text'
    },
    {
        label:'Stages',
        fieldName:'Stages__c',
        type:'picklist'
    }
];

export default class FactExeUi extends LightningElement {

columns = col;
result;
@wire(getCarModel)
carModelData({error,data})
{
    if(data)
    {
        this.result = data;
        this.error = undefined;;
        console.table(data);
    }
    else
    {
        this.error = error;
        this.result = undefined;
    }
}


}